/* 
 * @Author 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 
 var app=angular.module("bdf", []);
 
		app.controller("bdfCtrl",["$scope", function($scope) {
			$scope.quot = {};
			 $scope.nofpass = 1;
			 $scope.totdest = 2;
			 $scope.cabin = 'Business';
			
			$scope.onLoadFun = function(){
				// $scope.phone="+1 - ";
				 $scope.twowayclick();
				 $(function () {
					loadAutocompleteJquery();
					
				});
				$scope.loadDefaults();
			};
			
			 $scope.onewayId = angular.element(document.querySelector('#oneway' ));
			 $scope.twowayId  = angular.element(document.querySelector('#twoway' ));
			 $scope.multiwayId = angular.element(document.querySelector('#multiway' ));
			 
			
			 
			 $scope.adddestination = function(){
				 
				if($scope.totdest>=2 && $scope.totdest<5){
					$scope.showhidetrip(++$scope.totdest);
					
				}else {
				}
			};
			
			$scope.rmdestination = function(){
					
					if($scope.totdest>2 && $scope.totdest<=5){
						$scope.showhidetrip(--$scope.totdest);
					}else{
						
					}
			};
			
			$scope.showhidetrip = function(val){
			
				switch(val) {
					case 2 :
						$scope.showHideMultitripDiv(val,false,false,false);
						break;
					case 3:
						$scope.showHideMultitripDiv(val,true,false,false);
						break;
					case 4 :
						$scope.showHideMultitripDiv(val,true,true,false);
						break;
					case 5:
						$scope.showHideMultitripDiv(val,true,true,true);
						break;
					default : break;
				
				}
			};
			
			$scope.showHideMultitripDiv = function(val,three,four,five){
						$scope.totdest = val;//re-assigning to avoid multi-cahnges
						$scope.multi3 = three;
						$scope.multi4 = four;
						$scope.multi5 = five;
			};
			
			$scope.addpassenger = function(){
				
				if($scope.nofpass >= 5){
					console.log("do nothing");
				} else {
					$scope.nofpass++;
				}
			};
			
			$scope.removepassenger = function(){
				if($scope.nofpass <= 5 && $scope.nofpass > 1){
					$scope.nofpass--;
				}else{
				
				}
			};
			
			$scope.togglePassCabin = function(){
				$scope.cabinpass = !$scope.cabinpass;
			};
			
			$scope.onewayclick = function(){
				$scope.showhidetrip(2);//this is to multipletrip value submission
				$scope.showHideDiv(true,false,true);
				$scope.loadActiveState('active','','');
				$scope.trip = 'oneway';
			};
			$scope.twowayclick = function(){
				//console.log("called...;;;;");
				 $scope.loadActiveState('','active','');
				 $scope.showHideDiv(true,false,false);
				$scope.showhidetrip(2);//this is to multipletrip value submission
				$scope.trip = 'roundtrip';
			};
			
			$scope.multiwayclick = function(){
				
				$scope.showHideDiv(false,true,false);
				//$scope.showhidetrip(2);//this is to multipletrip value submission
				$scope.loadActiveState('','','active');
				$scope.trip = 'multicity';
				
				
				
			};
			
			
			
			$scope.loadActiveState = function(oneway,twoway,multiway){
				$scope.oneway = oneway;
				$scope.twoway = twoway;
				$scope.multiway = multiway;
				$(function () {
					/**
						Please TODO why you want to define the function in startup$(fun)
					**/
					loadAutocompleteJquery();
				});
			}
			
			$scope.showHideDiv = function(onewaydiv,multiwaydiv,returndisab){
				$scope.onewaydiv = onewaydiv;
				$scope.multiwaydiv = multiwaydiv;
				$scope.returndaydis = returndisab;   
			}
			
			$scope.submitForm = function(){
				//console.log($scope.name);
				$scope.quot.trip = $scope.trip;
				$scope.quot.name = $scope.name;
				$scope.quot.phonenumber =  $scope.phone;
				$scope.quot.email = $scope.email;
				$scope.quot.noofpassengers = $scope.nofpass;
				$scope.quot.cabin = $scope.cabin;
				$scope.quot.from = $scope.from;
				$scope.quot.to = $scope.to;
				$scope.quot.departuredate = $scope.departuredate;
				$scope.quot.returndate = $scope.returndate;
				$scope.quot.comment= $scope.comment;
				
				
				
				if($scope.trip == 'multicity'){
					
					$scope.quot.from1 = $scope.from1;
					$scope.quot.to1 = $scope.to1;
					$scope.quot.departuredate1 = $scope.departuredate1;
					
					$scope.quot.from2 = $scope.from2;
					$scope.quot.to2 = $scope.to2;
					$scope.quot.departuredate2 = $scope.departuredate2;
					
					$scope.quot.from3 = $scope.from3;
					$scope.quot.to3 = $scope.to3;
					$scope.quot.departuredate3 = $scope.departuredate3;
					
					$scope.quot.from4 = $scope.from4;
					$scope.quot.to4 = $scope.to4;
					$scope.quot.departuredate4 = $scope.departuredate4;
					
					$scope.quot.from5 = $scope.from5;
					$scope.quot.to5 = $scope.to5;
					$scope.quot.departuredate5 = $scope.departuredate5;
					
				}
				
				console.log($scope.quot);
				
			};
			
			$scope.loadDefaults = function(){
				$scope.name= "";
				//$scope.selected= "";
				//$scope.phone= "";
				$scope.email= "";
				//$scope.nofpass= "";
				//$scope.cabin= "";
				$scope.from= "";
				$scope.to= "";
				$scope.departuredate= "";
				$scope.returndate= "";
				$scope.comment= "";
				$scope.from1= "";
				$scope.to1= "";
				$scope.departuredate1= "";
				$scope.from2= "";
				$scope.to2= "";
				$scope.departuredate2= "";
				$scope.from3= "";
				$scope.to3= "";
				$scope.departuredate3= "";
				$scope.from4= "";
				$scope.to4= "";
				$scope.departuredate4= "";
				$scope.from5= "";
				$scope.to5= "";
				$scope.departuredate5= "";
				
			};
			
	}]);

	

loadAutocompleteJquery = function(){
			$(".autocomplete").autocomplete({
						//cityCountryAirportCode value should be fetched from airportList.js file
						source: function (request, response) {
							var results = $.ui.autocomplete.filter(cityCountryAirportCode, request.term);
							response(results.slice(0, 10));
						}

					});
					
			 $('.departuredate').datepicker(
            {
                showButtonPanel: true, minDate: 0, maxDate: "+12M",
                beforeShow: function () {
                    $(this).datepicker('option', 'maxDate', $('.departuredate').val());
                }
            });
			$('.returndate').datepicker(
					{
						showButtonPanel: true, defaultDate: "+1w", maxDate: "+12M",
						beforeShow: function () {
							$(this).datepicker('option', 'minDate', $('.departuredate').val());
							if ($('.departuredate').val() === '')
								$(this).datepicker('option', 'minDate', 0);
						}
			});
};